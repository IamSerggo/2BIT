<?php

class OPcodeError extends Exception
{

}