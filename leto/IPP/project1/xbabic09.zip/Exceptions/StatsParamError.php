<?php

class StatsParamError extends Exception {

}