<?php
/**
 * Created by PhpStorm.
 * User: radovan
 * Date: 4.3.2019
 * Time: 17:12
 */

class ProgramArgsError extends Exception {

}