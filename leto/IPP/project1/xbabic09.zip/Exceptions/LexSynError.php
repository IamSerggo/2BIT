<?php
/**
 * Created by PhpStorm.
 * User: radovan
 * Date: 2.3.2019
 * Time: 17:14
 */

class LexSynError extends Exception
{

}