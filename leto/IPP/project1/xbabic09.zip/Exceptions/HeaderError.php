<?php


class HeaderError extends Exception
{

}